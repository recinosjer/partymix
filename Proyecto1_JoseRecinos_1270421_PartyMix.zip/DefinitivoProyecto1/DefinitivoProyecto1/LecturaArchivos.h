#pragma once
#include "DecCancion.h"
class LecturaArchivos
{
public:
	int totalLines = 0;
	DecCancion* LeerArchivo(std::string nombreArc);
	//lee el archivo y almacena las canciones
	void EscribirArchivo(std::string nombreArc, DecCancion Stdlist_cancion[], int tama�o);
	//crea una archivo con una lista de las canciones de la playlist
};
