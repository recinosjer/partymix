#include "LecturaArchivos.h"
#include <fstream>
#include <iostream>
#include <list>
#include <sstream>
using namespace System::Windows::Forms;
DecCancion* LecturaArchivos::LeerArchivo(std::string nombreArc) {
	std::fstream Archivo;
	Archivo.open(nombreArc, std::ios_base::in);
	std::string linea;
	int TotalLines = 0;
		static DecCancion stdList_canciones_arc[200];
	while (Archivo.good()) {
		getline(Archivo, linea, ',');//Se coloca la , porque esta como un delimitador

		std::stringstream X(linea);
		int countT = 0;
		std::string lineaT;

		while (getline(X, lineaT, '-')) {//Este es el delimitador2  - 
			if (countT == 0) {
				stdList_canciones_arc[TotalLines].NombreCancion = lineaT;
			}

			if (countT == 1) {
				stdList_canciones_arc[TotalLines].Artista = lineaT;
			}
			countT = countT +1;
		}
		if (countT==1)// le a�adimos la condicion de que si no tiene artista, se colocara desconocido
		{
			stdList_canciones_arc[TotalLines].Artista = "Desconocido";
		}
		TotalLines = TotalLines + 1;
	}
	Archivo.close();
	return stdList_canciones_arc;
}
void LecturaArchivos::EscribirArchivo(std::string nombreArc, DecCancion Stdlist_cancion[], int tama�o) {//Crea el archivo con la ultima playlist

	std::ofstream ArchivoNuevo;
	ArchivoNuevo.open(nombreArc, std::ios_base::app);
	if (!ArchivoNuevo) {
		MessageBox::Show("Paso algo inesperado, no se creo el archivo", "Error", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
	else {
		std::string cancion;
		for (int i = 0; i < tama�o; i++) {
			cancion = Stdlist_cancion[i].NombreCancion + "-" + Stdlist_cancion[i].Artista;
			if (i == tama�o - 1) {
				ArchivoNuevo << cancion << std::endl;
			}
			else {
				ArchivoNuevo << cancion << "," << std::endl;
			}
		}
		ArchivoNuevo.close();
	}

}