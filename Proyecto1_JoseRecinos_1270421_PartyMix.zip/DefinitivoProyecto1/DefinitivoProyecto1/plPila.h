#pragma once
#include "DecCancion.h"
class plPila
{
	struct Node {
		DecCancion cancion;
		Node* next;
	};
private:
	Node* frente = nullptr;
public:
	plPila();
	void Push(DecCancion cancion); //Coloca la cancion ingresada de primero
	void Pop(); 
	// Saca la cancion que esta de primero 
	void Clear(); 
	// Eliminar� o vaciar�  la playlist
	int Count(); 
	//Devuelve la cantidad de elementos
	DecCancion* GetTop(); 
	// Regresa la primera cancion
	DecCancion* ToArray();
	std::string ShowPila(); 
	// DEVUELVE UNA CADENA con las lista
	
};



