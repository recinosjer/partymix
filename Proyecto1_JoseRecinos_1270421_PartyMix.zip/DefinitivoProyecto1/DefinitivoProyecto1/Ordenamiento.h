#include "DecCancion.h"
class Ordenamiento
{
public:
	DecCancion* StartBubbleSort(DecCancion* stdList_canciones, int tama�o, int ArtNum);//SE DECALRA EL METODO DE ORDENAMIENTO
private:
	void BubbleSortNombreCan(DecCancion* stdList_canciones, int med);//SE CREA LAS FUNCIONES DEL METOOD
	void BubbleSortArtista(DecCancion* stdList_canciones, int med);//SE CREA LAS FUNCIONES DEL METOOD
	std::string MakeItUpper(std::string palabra); // Se utiliza para poder convertir la primera letra mayucula y ya le permita realizar las comparaciones al metodo  
};

