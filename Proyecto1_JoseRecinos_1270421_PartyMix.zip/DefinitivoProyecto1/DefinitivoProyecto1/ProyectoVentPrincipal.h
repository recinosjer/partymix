#pragma once
#include <msclr\marshal_cppstd.h>
#include "LecturaArchivos.h"
#include "Cola.h"
#include "DecCancion.h"
#include "plPila.h"
#include "Ordenamiento.h"

namespace DefinitivoProyecto1 {
	LecturaArchivos archivo;
	DecCancion* stdList_canciones;
	Cola* Queue = new Cola();
	plPila* PilaPlaylist = new plPila();
	Ordenamiento ordenar;


	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de ProyectoVentPrincipal
	/// </summary>
	public ref class ProyectoVentPrincipal : public System::Windows::Forms::Form
	{
	public:
		ProyectoVentPrincipal(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~ProyectoVentPrincipal()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::RichTextBox^ richTextBox1Pila;
	protected:
	private: System::Windows::Forms::RichTextBox^ richTextBox2Cola;
	private: System::Windows::Forms::Button^ button_AgregarCancionCola;
	private: System::Windows::Forms::Button^ buttonElimiCola;

	private: System::Windows::Forms::Button^ buttonOrdNom;
	private: System::Windows::Forms::Button^ buttonOrdArt;
	private: System::Windows::Forms::Button^ buttonCrearArc;
	private: System::Windows::Forms::Button^ buttonImporArc;






	private: System::Windows::Forms::Button^ butRePa;
	private: System::Windows::Forms::Button^ buttonEmparejar;


	private: System::Windows::Forms::TextBox^ txtBoxNombreCan;
	private: System::Windows::Forms::TextBox^ txtBoxArt;


	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ txtBoxNombreArc;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TextBox^ textBoxSonando;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Timer^ timer1;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::Label^ label11;
	private: System::Windows::Forms::Label^ label12;
	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(ProyectoVentPrincipal::typeid));
			this->richTextBox1Pila = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox2Cola = (gcnew System::Windows::Forms::RichTextBox());
			this->button_AgregarCancionCola = (gcnew System::Windows::Forms::Button());
			this->buttonElimiCola = (gcnew System::Windows::Forms::Button());
			this->buttonOrdNom = (gcnew System::Windows::Forms::Button());
			this->buttonOrdArt = (gcnew System::Windows::Forms::Button());
			this->buttonCrearArc = (gcnew System::Windows::Forms::Button());
			this->buttonImporArc = (gcnew System::Windows::Forms::Button());
			this->butRePa = (gcnew System::Windows::Forms::Button());
			this->buttonEmparejar = (gcnew System::Windows::Forms::Button());
			this->txtBoxNombreCan = (gcnew System::Windows::Forms::TextBox());
			this->txtBoxArt = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtBoxNombreArc = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->textBoxSonando = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// richTextBox1Pila
			// 
			this->richTextBox1Pila->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(0)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->richTextBox1Pila->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->richTextBox1Pila->ForeColor = System::Drawing::Color::White;
			this->richTextBox1Pila->Location = System::Drawing::Point(36, 85);
			this->richTextBox1Pila->Name = L"richTextBox1Pila";
			this->richTextBox1Pila->Size = System::Drawing::Size(262, 265);
			this->richTextBox1Pila->TabIndex = 0;
			this->richTextBox1Pila->Text = L"Sin canciones";
			// 
			// richTextBox2Cola
			// 
			this->richTextBox2Cola->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(0)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->richTextBox2Cola->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->richTextBox2Cola->ForeColor = System::Drawing::Color::White;
			this->richTextBox2Cola->Location = System::Drawing::Point(310, 85);
			this->richTextBox2Cola->Name = L"richTextBox2Cola";
			this->richTextBox2Cola->Size = System::Drawing::Size(240, 265);
			this->richTextBox2Cola->TabIndex = 1;
			this->richTextBox2Cola->Text = L"Sin canciones";
			// 
			// button_AgregarCancionCola
			// 
			this->button_AgregarCancionCola->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button_AgregarCancionCola.BackgroundImage")));
			this->button_AgregarCancionCola->ForeColor = System::Drawing::Color::White;
			this->button_AgregarCancionCola->Location = System::Drawing::Point(713, 97);
			this->button_AgregarCancionCola->Name = L"button_AgregarCancionCola";
			this->button_AgregarCancionCola->Size = System::Drawing::Size(135, 34);
			this->button_AgregarCancionCola->TabIndex = 2;
			this->button_AgregarCancionCola->Text = L"Agregar  Cancion A Cola";
			this->button_AgregarCancionCola->UseVisualStyleBackColor = true;
			this->button_AgregarCancionCola->Click += gcnew System::EventHandler(this, &ProyectoVentPrincipal::button_AgregarCancionCola_Click);
			// 
			// buttonElimiCola
			// 
			this->buttonElimiCola->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"buttonElimiCola.BackgroundImage")));
			this->buttonElimiCola->Location = System::Drawing::Point(713, 137);
			this->buttonElimiCola->Name = L"buttonElimiCola";
			this->buttonElimiCola->Size = System::Drawing::Size(135, 36);
			this->buttonElimiCola->TabIndex = 3;
			this->buttonElimiCola->Text = L"Eliminar  Cancion De Cola";
			this->buttonElimiCola->UseVisualStyleBackColor = true;
			this->buttonElimiCola->Click += gcnew System::EventHandler(this, &ProyectoVentPrincipal::buttonElimiCola_Click);
			// 
			// buttonOrdNom
			// 
			this->buttonOrdNom->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"buttonOrdNom.BackgroundImage")));
			this->buttonOrdNom->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 8.249999F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonOrdNom->Location = System::Drawing::Point(310, 414);
			this->buttonOrdNom->Name = L"buttonOrdNom";
			this->buttonOrdNom->Size = System::Drawing::Size(131, 27);
			this->buttonOrdNom->TabIndex = 4;
			this->buttonOrdNom->Text = L"Nombre de Cancion";
			this->buttonOrdNom->UseVisualStyleBackColor = true;
			this->buttonOrdNom->Click += gcnew System::EventHandler(this, &ProyectoVentPrincipal::button3_Click);
			// 
			// buttonOrdArt
			// 
			this->buttonOrdArt->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"buttonOrdArt.BackgroundImage")));
			this->buttonOrdArt->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 8.249999F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonOrdArt->Location = System::Drawing::Point(310, 447);
			this->buttonOrdArt->Name = L"buttonOrdArt";
			this->buttonOrdArt->Size = System::Drawing::Size(131, 30);
			this->buttonOrdArt->TabIndex = 5;
			this->buttonOrdArt->Text = L"Artista";
			this->buttonOrdArt->UseVisualStyleBackColor = true;
			this->buttonOrdArt->Click += gcnew System::EventHandler(this, &ProyectoVentPrincipal::buttonOrdArt_Click);
			// 
			// buttonCrearArc
			// 
			this->buttonCrearArc->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->buttonCrearArc->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"buttonCrearArc.BackgroundImage")));
			this->buttonCrearArc->Location = System::Drawing::Point(59, 438);
			this->buttonCrearArc->Name = L"buttonCrearArc";
			this->buttonCrearArc->Size = System::Drawing::Size(131, 25);
			this->buttonCrearArc->TabIndex = 6;
			this->buttonCrearArc->Text = L"Crear archivo CSV";
			this->buttonCrearArc->UseVisualStyleBackColor = false;
			this->buttonCrearArc->Click += gcnew System::EventHandler(this, &ProyectoVentPrincipal::buttonCrearArc_Click);
			// 
			// buttonImporArc
			// 
			this->buttonImporArc->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->buttonImporArc->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"buttonImporArc.BackgroundImage")));
			this->buttonImporArc->Location = System::Drawing::Point(59, 479);
			this->buttonImporArc->Name = L"buttonImporArc";
			this->buttonImporArc->Size = System::Drawing::Size(121, 27);
			this->buttonImporArc->TabIndex = 7;
			this->buttonImporArc->Text = L"Importar Archivo CSV";
			this->buttonImporArc->UseVisualStyleBackColor = false;
			this->buttonImporArc->Click += gcnew System::EventHandler(this, &ProyectoVentPrincipal::buttonImporArc_Click);
			// 
			// butRePa
			// 
			this->butRePa->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"butRePa.BackgroundImage")));
			this->butRePa->Font = (gcnew System::Drawing::Font(L"Showcard Gothic", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->butRePa->Location = System::Drawing::Point(640, 497);
			this->butRePa->Name = L"butRePa";
			this->butRePa->Size = System::Drawing::Size(125, 32);
			this->butRePa->TabIndex = 9;
			this->butRePa->Text = L"II>";
			this->butRePa->UseVisualStyleBackColor = true;
			this->butRePa->Click += gcnew System::EventHandler(this, &ProyectoVentPrincipal::butRePa_Click);
			// 
			// buttonEmparejar
			// 
			this->buttonEmparejar->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"buttonEmparejar.BackgroundImage")));
			this->buttonEmparejar->Location = System::Drawing::Point(640, 440);
			this->buttonEmparejar->Name = L"buttonEmparejar";
			this->buttonEmparejar->Size = System::Drawing::Size(125, 42);
			this->buttonEmparejar->TabIndex = 10;
			this->buttonEmparejar->Text = L"Emparejar Cola con Playlist";
			this->buttonEmparejar->UseVisualStyleBackColor = true;
			this->buttonEmparejar->Click += gcnew System::EventHandler(this, &ProyectoVentPrincipal::buttonEmparejar_Click);
			// 
			// txtBoxNombreCan
			// 
			this->txtBoxNombreCan->BackColor = System::Drawing::Color::Purple;
			this->txtBoxNombreCan->ForeColor = System::Drawing::Color::White;
			this->txtBoxNombreCan->Location = System::Drawing::Point(581, 97);
			this->txtBoxNombreCan->Name = L"txtBoxNombreCan";
			this->txtBoxNombreCan->Size = System::Drawing::Size(100, 20);
			this->txtBoxNombreCan->TabIndex = 11;
			// 
			// txtBoxArt
			// 
			this->txtBoxArt->BackColor = System::Drawing::Color::Purple;
			this->txtBoxArt->ForeColor = System::Drawing::Color::White;
			this->txtBoxArt->Location = System::Drawing::Point(581, 153);
			this->txtBoxArt->Name = L"txtBoxArt";
			this->txtBoxArt->Size = System::Drawing::Size(100, 20);
			this->txtBoxArt->TabIndex = 12;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(0)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label1->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(569, 72);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(126, 15);
			this->label1->TabIndex = 13;
			this->label1->Text = L"Nombre de Cancion";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(64)), static_cast<System::Int32>(static_cast<System::Byte>(0)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label2->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(569, 129);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(51, 15);
			this->label2->TabIndex = 14;
			this->label2->Text = L"Artista";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label3->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(307, 378);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(121, 15);
			this->label3->TabIndex = 15;
			this->label3->Text = L"Ordenamiento por:";
			this->label3->Click += gcnew System::EventHandler(this, &ProyectoVentPrincipal::label3_Click);
			// 
			// txtBoxNombreArc
			// 
			this->txtBoxNombreArc->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->txtBoxNombreArc->ForeColor = System::Drawing::Color::White;
			this->txtBoxNombreArc->Location = System::Drawing::Point(59, 401);
			this->txtBoxNombreArc->Name = L"txtBoxNombreArc";
			this->txtBoxNombreArc->Size = System::Drawing::Size(157, 20);
			this->txtBoxNombreArc->TabIndex = 16;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(64)),
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label4->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(56, 372);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(123, 15);
			this->label4->TabIndex = 17;
			this->label4->Text = L"Nombre de archivo";
			// 
			// textBoxSonando
			// 
			this->textBoxSonando->BackColor = System::Drawing::Color::LightSkyBlue;
			this->textBoxSonando->ForeColor = System::Drawing::Color::White;
			this->textBoxSonando->Location = System::Drawing::Point(464, 509);
			this->textBoxSonando->Name = L"textBoxSonando";
			this->textBoxSonando->Size = System::Drawing::Size(156, 20);
			this->textBoxSonando->TabIndex = 18;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::Teal;
			this->label5->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(343, 511);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(115, 15);
			this->label5->TabIndex = 19;
			this->label5->Text = L"Estas escuchando";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->BackColor = System::Drawing::Color::Teal;
			this->label6->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(484, 541);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(136, 15);
			this->label6->TabIndex = 20;
			this->label6->Text = L"�Que  buena canci�n!";
			// 
			// timer1
			// 
			this->timer1->Enabled = true;
			this->timer1->Tick += gcnew System::EventHandler(this, &ProyectoVentPrincipal::timer1_Tick);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Palatino Linotype", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label7->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"label7.Image")));
			this->label7->Location = System::Drawing::Point(16, 9);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(174, 39);
			this->label7->TabIndex = 21;
			this->label7->Text = L"PARTYMIX";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label8->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->Location = System::Drawing::Point(33, 67);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(56, 15);
			this->label8->TabIndex = 22;
			this->label8->Text = L"Playlist";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label9->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(316, 67);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(34, 15);
			this->label9->TabIndex = 23;
			this->label9->Text = L"Cola";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label10->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->Location = System::Drawing::Point(569, 195);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(232, 15);
			this->label10->TabIndex = 24;
			this->label10->Text = L"Si no se sabe el nombre del artista, ";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label11->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label11->Location = System::Drawing::Point(569, 210);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(305, 15);
			this->label11->TabIndex = 25;
			this->label11->Text = L"dejelo en blanco y se colocara como desconocido";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->BackColor = System::Drawing::Color::Red;
			this->label12->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label12->Location = System::Drawing::Point(771, 511);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(180, 15);
			this->label12->TabIndex = 26;
			this->label12->Text = L"Para darle play a la musica";
			// 
			// ProyectoVentPrincipal
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(1031, 590);
			this->Controls->Add(this->label12);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->textBoxSonando);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtBoxNombreArc);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtBoxArt);
			this->Controls->Add(this->txtBoxNombreCan);
			this->Controls->Add(this->buttonEmparejar);
			this->Controls->Add(this->butRePa);
			this->Controls->Add(this->buttonImporArc);
			this->Controls->Add(this->buttonCrearArc);
			this->Controls->Add(this->buttonOrdArt);
			this->Controls->Add(this->buttonOrdNom);
			this->Controls->Add(this->buttonElimiCola);
			this->Controls->Add(this->button_AgregarCancionCola);
			this->Controls->Add(this->richTextBox2Cola);
			this->Controls->Add(this->richTextBox1Pila);
			this->ForeColor = System::Drawing::Color::White;
			this->Name = L"ProyectoVentPrincipal";
			this->Text = L"ProyectoVentPrincipal";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label3_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	int size = PilaPlaylist->Count();
	stdList_canciones = PilaPlaylist->ToArray();

	stdList_canciones = ordenar.StartBubbleSort(stdList_canciones, size, 0);// Se asigna la funcion de ordenar , con el valor de 0 para ordenar por nombre de cancion
	for (int i = 0; i < size; i++) {
		DecCancion* temp = new DecCancion();
		temp->NombreCancion = stdList_canciones[i].NombreCancion;//Asigna los datos ya ordenados 
		temp->Artista = stdList_canciones[i].Artista;//Asigna los datos ya ordenados 
		PilaPlaylist->Push(*temp);//Los inserta
	}
}
private: System::Void buttonCrearArc_Click(System::Object^ sender, System::EventArgs^ e) {
	System::String^ nombre_de_archivo_original = txtBoxNombreArc->Text; //Se le asigna que se guarde lo ingresado en el textbox
		//se utiliza marsahl para convertir el strting 

	msclr::interop::marshal_context context; 
	// Declaramos el marshal para su uso 
	std::string nombreArc  = context.marshal_as<std::string>(nombre_de_archivo_original); 	//se utiliza marsahl para convertir de System String a strting 
	int tama�o = PilaPlaylist->Count();
	stdList_canciones = PilaPlaylist->ToArray();

	archivo.EscribirArchivo(nombreArc, stdList_canciones, tama�o);
}

private: System::Void ShowQueueAndPlaylist() {
	 //Mostramos playlist
	std::string pilaPltTemp = PilaPlaylist->ShowPila();
	String^ PilaPlaylist = gcnew String(pilaPltTemp.c_str());
	 richTextBox1Pila->Text = PilaPlaylist;
	 // aqui termina el mostrar playlist
	 
   //Mostramos cola
   std::string QueueTemp = Queue->ShowQueue();
   String^ Queue = gcnew String(QueueTemp.c_str());
   richTextBox2Cola->Text = Queue;
   //Termina el mostrar cola



	   }
private: System::Void buttonImporArc_Click(System::Object^ sender, System::EventArgs^ e) {
	System::String^ nombArchA = txtBoxNombreArc->Text; //Se le asigna que se guarde lo ingresado en el textbox
		//se utiliza marsahl para convertir el strting 

	msclr::interop::marshal_context context; 
	// Declaramos el marshal para su uso 
	std::string nombreArc = context.marshal_as<std::string>(nombArchA); //se utiliza marsahl para convertir de System String a strting 
	stdList_canciones = archivo.LeerArchivo(nombreArc);
	int i = 0;

	while (stdList_canciones[i].NombreCancion != "" && stdList_canciones[i].Artista != "") {
		DecCancion* temp = new DecCancion();
		temp->NombreCancion = stdList_canciones[i].NombreCancion; temp->Artista = stdList_canciones[i].Artista;
		PilaPlaylist->Push(*temp);

		i++;
	}
}
private: System::Void buttonOrdArt_Click(System::Object^ sender, System::EventArgs^ e) {
	int size = PilaPlaylist->Count();
	stdList_canciones = PilaPlaylist->ToArray();

	stdList_canciones = ordenar.StartBubbleSort(stdList_canciones, size, 1);// Se asigna la funcion de ordenar 
	for (int i = 0; i < size; i++) {
		DecCancion* temp = new DecCancion();
	
		temp->Artista = stdList_canciones[i].Artista;//Asigna los datos ya ordenados 
		temp->NombreCancion = stdList_canciones[i].NombreCancion;//Asigna los datos ya ordenados 
		PilaPlaylist->Push(*temp);//Los inserta
	}
}
private: System::Void button_AgregarCancionCola_Click(System::Object^ sender, System::EventArgs^ e) {
	
	msclr::interop::marshal_context context;

	System::String^ nom = txtBoxNombreCan->Text;
	std::string nombCa = std::string(nombCa);
	nombCa = context.marshal_as<std::string>(nom);//Se le asigna la cancion ingresada en el txtBoxNombreCan, pero ya se hizo la conversion con Marshal, para que fuera compatible con string
	
	System::String^ ar = txtBoxArt->Text;
		if (ar=="") {
		
			ar = "Desconocido";		
		}
	std::string nombAr = std::string(nombAr);//Se le asigna la cancion ingresada en el txtBoxArt, pero ya se hizo la conversion con Marshal, para que fuera compatible con string
	nombAr = context.marshal_as<std::string>(ar);

	DecCancion* temp = new DecCancion();
	temp->NombreCancion = nombCa;
	temp->Artista = nombAr;
	Queue->AddToQueue(*temp);//Como ya se le asign� la cancion ingresada en los textBox se agrega por medio de la funcion agregar a Cola

}


private: System::Void buttonElimiCola_Click(System::Object^ sender, System::EventArgs^ e) {
	msclr::interop::marshal_context context;
	System::String^ nom = txtBoxNombreCan->Text;
	std::string nombCa = context.marshal_as<std::string>(nom);// Agrega el nombre de la cancion ingresado en el textBox a nombre_de_cancion

	System::String^ ar = txtBoxArt->Text;
	std::string nombAr = context.marshal_as<std::string>(ar);// Agrega el nombre de el artista ingresado en el textBox a  nombre_de_artista

	DecCancion* temp = new DecCancion();
	temp->NombreCancion = nombCa;//Agrega el valor ingresado en TextBos a NombreCancion
	temp->Artista = nombAr;//Agrega el valor ingresado en TextBos a Artista
	Queue->RemoveFromQueue(*temp);//Se manda a llamar la funcion Remove por medio de la cual se elimina la cancion de la cola
}
private: System::Void butRePa_Click(System::Object^ sender, System::EventArgs^ e) {

		DecCancion* SuenaCan = new DecCancion();
		SuenaCan = PilaPlaylist->GetTop();
	try
	{

		if (PilaPlaylist->Count() == 0) {
			while (!Queue->EstaVacia()) {
				DecCancion temp;
				temp = Queue->Pop(); //Se elimina la cancion qu esta reproduciendo
				PilaPlaylist->Push(temp);
			}
		}
		std::string temp = SuenaCan->NombreCancion + "-" + SuenaCan->Artista;// le asignamos la cancion que esta reproduciendo al temp
		String^ SoundCan = gcnew String(temp.c_str());
		textBoxSonando->Text = SoundCan; //Se le asigna la cancion que esta reproduciendo al textBox
		PilaPlaylist->Pop();

	}
	catch (...)
	{
		MessageBox::Show("No hay canciones, agregue una", "Error", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}

}
private: System::Void buttonEmparejar_Click(System::Object^ sender, System::EventArgs^ e) {
	while (!Queue->EstaVacia()) {
		DecCancion temp;
		temp = Queue->Pop();
		PilaPlaylist->Push(temp);// Agrega las canciones de la cola a la playlist
	}
}
private: System::Void timer1_Tick(System::Object^ sender, System::EventArgs^ e) {
	ShowQueueAndPlaylist();//Esta actualizando la playlist c�da cierto periodo de tiempo
}

};
}
