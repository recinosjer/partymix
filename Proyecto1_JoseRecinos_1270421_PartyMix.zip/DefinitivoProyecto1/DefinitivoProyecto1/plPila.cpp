#include "plPila.h"

plPila::plPila() {
	this->frente = nullptr;
}
void plPila::Push(DecCancion cancion) { //Con el push se inserta un nuevo elemento en el tope de la pila
	Node* nuevo = new Node();
	nuevo->cancion = cancion;
	nuevo->next = frente;
	frente = nuevo; //Se le asigna el valor de nuevo al header 
}

void plPila::Pop() { // se crea el pop para poder eleminar el primer elemento que es el frente
	Node* elim = frente;
	frente = frente->next;
	delete (elim); //Aqui se puede elminaminar el header 
}

int plPila::Count() { //calculamos el numero de valores 
	int cancio_to = 0;
	Node* temp = frente;
		while (temp) {
		cancio_to += 1;
		temp = temp->next;
		}
	return cancio_to; //Retornamos el numero de valores
}

void plPila::Clear() {//Limpiamos la cola
	frente = nullptr; 
}

DecCancion* plPila::GetTop() {// envia la primera cancion
	return (&frente->cancion);
}

std::string plPila::ShowPila() { //Se crea la implementacion para mostrar pila
	Node* temp = frente;  //Se le asigna al temporal el valor del header 
	std::string cola = "";
	while (temp != nullptr) { //Por medio del while nos permite ver si esta vacia, si lo esta solo manda la cola
		cola += temp->cancion.NombreCancion + "-" + temp->cancion.Artista + "\n";
		temp = temp->next;
	}
	return cola;
}

DecCancion* plPila::ToArray() {
	static DecCancion str_canciones_arc[200];
	int i = 0;
	while (frente != nullptr) {
		str_canciones_arc[i] = frente->cancion;
		frente = frente->next;
		i++;
	}
	return str_canciones_arc;
}