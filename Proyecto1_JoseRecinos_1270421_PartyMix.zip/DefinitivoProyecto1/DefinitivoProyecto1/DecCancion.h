#pragma once
#include <iostream>
class DecCancion
{
public://CREA LOS ATRIBUTOS DE LA CLASE
	std::string NombreCancion;
	std::string Artista;
};

