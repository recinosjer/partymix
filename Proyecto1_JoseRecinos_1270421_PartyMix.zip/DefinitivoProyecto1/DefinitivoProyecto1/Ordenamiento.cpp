#include "Ordenamiento.h"
#include <stdlib.h>
#include <ctype.h>
DecCancion* Ordenamiento::StartBubbleSort(DecCancion* stdList_canciones, int med, int nombreArt) {
	if (nombreArt == 0) {// SE ASIGNA EL VALOR DE 0 PARA IDENTIFICAR CUAL METODO SE MANDA A LLAMAR
		BubbleSortNombreCan(stdList_canciones, med);
	}
	else if (nombreArt == 1) {
		BubbleSortArtista(stdList_canciones, med);
	}
	return stdList_canciones;
}
void Ordenamiento::BubbleSortArtista(DecCancion* stdList_canciones, int med) {//ORDENA LAS CANCIONES POR ARTISTAS
	DecCancion temp;
	for (int i = 0; i < med; i++) {
		for (int j = 0; j < med; j++) {
			std::string can1 = stdList_canciones[j].Artista;
			std::string can2 = stdList_canciones[j + 1].Artista;

			if (MakeItUpper(can1) < MakeItUpper(can2)) {//SE REALIZA LA COMPARACION PARA ORDENAR LAS CANCIONES
				temp = stdList_canciones[j];
				stdList_canciones[j] = stdList_canciones[j + 1];
				stdList_canciones[j + 1] = temp;
			}
		}
	}
}

void Ordenamiento::BubbleSortNombreCan(DecCancion* stdList_canciones, int med) {//ORDENA LAS CANCIONES POR SU NOMBRE
	DecCancion temp;
	for (int i = 0; i < med; i++) {
		for (int j = 0; j < med; j++) {
			std::string can1 = stdList_canciones[j].NombreCancion;//Se usa un temporal para poder realizar las comparaciones 
			std::string can2 = stdList_canciones[j + 1].NombreCancion;//Se usa un temporal para poder realizar las comparaciones

			if (MakeItUpper(can1) < MakeItUpper(can2)) { //Realiza las comparaciones para poder ordenarlo
				temp = stdList_canciones[j];
				stdList_canciones[j] = stdList_canciones[j + 1];
				stdList_canciones[j + 1] = temp;
			}
		}
	}
}



std::string Ordenamiento::MakeItUpper(std::string palabra) {
	int tama�opalabra = palabra.size();//Obtenemos el tama�o de la palabra con el .size
	for (int i = 0; i < tama�opalabra; i++) {
		palabra[i] = toupper(palabra[i]);//El .toupper cambia de minuscula a mayuscula y eso ayuda a poder ordenarnlo en el bubble sort	}
	}
		return palabra;
}