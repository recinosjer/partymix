#pragma once
#include "DecCancion.h"
class Cola
{
	struct Node { //Se declara la estructura
		DecCancion cancion;
		Node* next;
	};
private:
	Node* frente = nullptr;//Se declara como el header
	Node* ultimo = nullptr;//Es la ultima cancion, no recuerdo el nombre ahorita jaja :)
public:
	Cola();
	void AddToQueue(DecCancion cancion); 
	// a�ade una cancion en la cola

	void RemoveFromQueue(DecCancion cancion); 
	// quita la cancion de la cola

	int Count(); 
	//Devuelve la cantidad de elementos

	bool EstaVacia();
	//Verifica si esta vacia, si lo esta enviar� true

	DecCancion Pop();
	// Elimina la cancion, DESPUES DE PASARLA A LA PLAYLIST 

	DecCancion GetTop(); 
	//Devuelve la primera cancion

	std::string ShowQueue();
	// devolvera la fila con la cadena , es decir mostrara la cola
};

