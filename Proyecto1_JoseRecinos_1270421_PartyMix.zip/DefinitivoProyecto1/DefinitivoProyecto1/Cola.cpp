#include "Cola.h"
using namespace System::Windows::Forms;
Cola::Cola() {
	this->frente = nullptr;
	this->ultimo = nullptr;
}
void Cola::AddToQueue(DecCancion cancion) {//SE AGREGAN VALORES A LA COLA
	Node* nuevo = new Node();
	nuevo->cancion = cancion;
	nuevo->next = nullptr;
	if (frente == nullptr) {// SIRVE PARA CORROBAR QUE LA COLA ESTE VACIA
		frente = nuevo;//SI ESTA VACIA SE LE ASIGNA EL VALOR DE NUEVO
	}
	else {
		ultimo->next = nuevo;
	}
	ultimo = nuevo;
}

void Cola::RemoveFromQueue(DecCancion cancion) {// ESTO SIRVE PARA REMOVER LA PRIMERA CANCION DE COLA
	if (frente != nullptr) {// SE CORROBARA QUE SEA DIFERENTE A NULO
		Node* elimBo;
		Node* anterior = nullptr;
		elimBo = frente;//SE LE ASIGNA LA PRIMERA CANCION Y DESPUES SE ELIMINARA ESTA VARIABLE
		while (elimBo != nullptr && (elimBo->cancion.NombreCancion != cancion.NombreCancion && elimBo->cancion.Artista != cancion.Artista)) {//VERIFICA SI ESTA VACIO 
			anterior = elimBo;
			elimBo = elimBo->next;
		}
		if (elimBo == nullptr) {
				
				MessageBox::Show("INGRESE UNA CANCION QUE SI EXISTA", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
		else if (anterior == nullptr) {
				frente = frente->next;
				delete (elimBo); // SE ELIMINA LA CANCION
		}
		else {
				anterior->next = elimBo->next;// EL ANTERIOR TOMA AL VALOR SIGUIENTE
				delete (elimBo);// Y SE ELIMINA LA CANCION
		}
	}
	else {
		
		MessageBox::Show("ESTA VACIA , POR FAVOR LLENELA ANTES", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
}

int Cola::Count() { //RELIZA EL CONTEO DE LA CANTIDAD DE ELEMENTOS DE LA COLA
	int cancio_to = 0;
	if (frente == nullptr) {
		return 0;
	}
	else {
		Node* temp = frente;
		while (temp != nullptr) {// POR MEDIO DEL WHILE SE CONDICIONA SI ES DIFERENTE A NULO PARA QUE PUEDO IR AVANZANDO EN A OTRO ELEMENTO, HASTA QUE SEA NULO
			cancio_to += 1; // SE ACUMULA EL NUMERO DE CANCIONES
			temp = temp->next;
		}
		return cancio_to;// DEVUELVE EL TOTAL DE ELEMENTOS DE LA CANCION
	}
}

std::string Cola::ShowQueue() { //MUESTRA LA COLA
	Node* temp = frente;
	std::string cola = "";
	while (temp != nullptr) {
		if (temp->next == nullptr) {
			cola += temp->cancion.NombreCancion + "-" + temp->cancion.Artista;
		}
		else {
			cola += temp->cancion.NombreCancion + "-" + temp->cancion.Artista + "\n";
		}
		temp = temp->next;
	}
	return cola;
}

bool Cola::EstaVacia() {// VERIFICA SI ESTA VACIA LA COLA
	return (frente == nullptr) ? true : false;// SI ESTA VACIA DEVOLVERA TRU
}

DecCancion Cola::Pop() {//SIRVE PARA  ELIMINAR LA CANCION CUANDO SE PASA A PLAYLIST
	Node* elim = new Node();
	elim = frente;
	if (frente == nullptr) {
		MessageBox::Show("No se puede, porque ahorita no tiene nada, es decir, esta vacia", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Information);

		return frente->cancion;
	}
	else {
		frente = frente->next;
		return (elim->cancion);
		delete (elim);
	}


}

DecCancion Cola::GetTop() { //DEVUELVE LA PRIMERA CANCION
	return frente->cancion;//SE ASIGNA  A FRENTE
}